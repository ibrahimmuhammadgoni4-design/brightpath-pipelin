# GROUP 1 — DIFFERENTIAL DIAGNOSIS PIPELINE
## Template 29 interior | Navy/Teal/Red | Numbered sections | Indented paragraphs

## 8 BOOKS
1. Advanced Practice Nursing: Differential Diagnosis (CLAUDE HAIKU) — $2.79
2. Clinical Reasoning and Differential Diagnosis (DEEPSEEK) — $1.76
3. Differential Diagnosis at the Bedside 6x9 (DEEPSEEK)
4. Primary Care Differential Diagnosis (DEEPSEEK)
5. Family Medicine Differential Diagnosis Workbook (DEEPSEEK)
6. Psychiatry Differential Diagnosis in Primary Care (DEEPSEEK)
7. Endocrinology Differential Diagnosis (DEEPSEEK)
8. Cardiology Differential Diagnosis in Primary Care (DEEPSEEK)

## SETUP
1. cp .env.template .env
2. Edit .env — add your API keys:
   ANTHROPIC_API_KEY=sk-ant-...
   DEEPSEEK_API_KEY=sk-...
   OPENAI_API_KEY=sk-proj-...
3. pip install reportlab pillow openai requests matplotlib anthropic numpy
4. python Group1_Pipeline/pipeline/main.py

## TEST FIRST (default)
TEST_MODE=True in config.py → runs Book 1 only
Check pdfs/ and covers/
If good: set TEST_MODE=False → runs all 8

## WHAT THE PIPELINE DOES
1. Calls Claude Haiku API (Book 1) or DeepSeek API (Books 2-8)
2. Returns Python list of content tuples
3. Quality gate: score 80+ required
4. Generates matplotlib code figures (free)
5. Builds EN PDF using Template 29 interior exactly
6. Calls OpenAI for EN cover
7. Writes German content fresh via same API
8. Builds DE PDF using Template 29 interior exactly
9. Calls OpenAI for DE cover
10. Writes metadata
11. Never stops — fallback content if API fails
12. Saves state every chapter — resumes if crashed

## EXACT COSTS
Book 1 (Claude):   $2.79
Books 2-8 (DS):    $1.76 each × 7 = $12.32
Covers all 8:      already in above costs
TOTAL all 8:       ~$15.11

## INTERIOR ELEMENTS (Template 29 exactly)
✅ Title page: red small caps + double rules + large serif + publisher
✅ Chapter opener: red part label + navy rule + Chapter N + large title
✅ Learning objectives: dark navy banner + light grey bullets
✅ Section headings: X.Y  Teal bold sans
✅ Drop cap: large serif letter on first paragraph only
✅ Body text: indented first line, justified
✅ Key concept callout: teal label + burgundy border + grey background
✅ Clinical correlation callout: same style
✅ Pull quote: large italic centred, white space
✅ Figures: nested circles, 2×2 box grid, flowchart, ECG
✅ Table: caption above + minimal rules
✅ Chapter summary: dark navy banner + grey body
✅ Review questions: dark navy bar + numbered grey box
✅ Running headers: italic serif left + bold "Chapter N" right + rule
✅ Page numbers: centred bottom
