# Figure generator — code figures free, covers OpenAI
# All figure types match Template 29 style exactly
import io, re, requests, math
from pathlib import Path
from config import OPENAI_API_KEY, OPENAI_MODEL, OPENAI_QUALITY, OPENAI_SIZE, OPENAI_COST
from spend import can_openai, log_openai

# Template 29 colour palette
NAVY  = "#1E2E4A"
TEAL  = "#1B6B7B"
RED   = "#8C1F28"
LGREY = "#F0F0F0"
INK   = "#111111"

def cover(title, subtitle, author, specialty, output_path, book_id, lang="EN"):
    """Generate cover — OpenAI illustration + Python text overlay"""
    if not can_openai():
        print(f"  ⛔ OpenAI — skip cover {lang}"); return False
    prompt=(f"Professional academic medical textbook cover. "
            f"Medical specialty: {specialty}. "
            f"NO TEXT NO TITLE NO WORDS in image. "
            f"Navy blue, teal, and cream colour palette. "
            f"Clean academic aesthetic. Premium quality.")
    try:
        from openai import OpenAI
        client=OpenAI(api_key=OPENAI_API_KEY)
        resp=client.images.generate(model=OPENAI_MODEL,prompt=prompt,
            quality=OPENAI_QUALITY,size=OPENAI_SIZE,n=1)
        img_bytes=requests.get(resp.data[0].url).content
        from PIL import Image,ImageDraw,ImageFont
        img=Image.open(io.BytesIO(img_bytes)).resize((1600,2400),Image.LANCZOS)
        draw=ImageDraw.Draw(img)
        try:
            ft_title=ImageFont.truetype("/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",52)
            ft_sub  =ImageFont.truetype("/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf",34)
            ft_auth =ImageFont.truetype("/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",36)
        except: ft_title=ft_sub=ft_auth=ImageFont.load_default()
        # Dark overlay top
        ov=Image.new('RGBA',(1600,550),(30,46,74,220))
        img.paste(ov,(0,0),ov)
        # Title text
        lines=[title[i:i+38] for i in range(0,len(title),38)]
        for i,ln in enumerate(lines[:3]):
            draw.text((80,60+i*65),ln,fill=(255,255,255,255),font=ft_title)
        if subtitle:
            draw.text((80,260),subtitle[:55],fill=(180,210,220,255),font=ft_sub)
        # Dark overlay bottom
        ov2=Image.new('RGBA',(1600,180),(30,46,74,220))
        img.paste(ov2,(0,2220),ov2)
        draw.text((80,2240),author,fill=(194,194,150,255),font=ft_auth)
        img.convert('RGB').save(str(output_path),format='PNG',dpi=(300,300))
        log_openai(book_id,f"cover_{lang}")
        print(f"  ✅ Cover {lang}")
        return True
    except Exception as e:
        print(f"  ❌ Cover {lang}: {e}"); return False

def parse_content_for_figs(content_list, ds_label_fn, book_no, ch_num, fig_dir, book_id):
    """
    content_list is already a Python list of tuples from the API.
    This function generates matplotlib figures for code figure tuples
    and returns updated list with file paths embedded.
    """
    import matplotlib; matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    import matplotlib.patches as mpt
    import numpy as np

    fig_dir = Path(fig_dir)
    fig_dir.mkdir(parents=True, exist_ok=True)
    updated = []
    fig_count = 0

    for item in content_list:
        kind = item[0] if item else ""

        if kind in ("fig_nested","fig_boxgrid","fig_flowchart","fig_ecg"):
            fig_count += 1
            fp = fig_dir / f"b{book_no:03d}_c{ch_num:02d}_f{fig_count:02d}.png"

            try:
                if kind == "fig_nested":
                    _draw_nested(item[1], fp)
                elif kind == "fig_boxgrid":
                    _draw_boxgrid(item[1], fp)
                elif kind == "fig_flowchart":
                    _draw_flowchart(item[1], fp)
                elif kind == "fig_ecg":
                    _draw_ecg(item[1], fp)
                # Return tuple with file path instead of labels
                updated.append((kind, str(fp), item[-2], item[-1]))
            except Exception as e:
                print(f"  ⚠️ Fig {fig_count}: {e}")
                updated.append(item)
        else:
            updated.append(item)

    return updated

def _draw_nested(labels, fp, w=3.2, h=2.8):
    import matplotlib; matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(w,h), dpi=300)
    ax.set_xlim(0,10); ax.set_ylim(0,10); ax.axis('off')
    fig.patch.set_facecolor('white')
    cx,cy = 5,5
    radii = [4.2,2.8,1.5]
    fills = ['#D8E8F0','#B8D0E8','#8CAECC']
    edges = ['#7AAAC8',RED,NAVY]
    lbls = (labels or ["Purpose","Arrangement","Material"])[:3]
    for r,f,e in zip(radii,fills,edges):
        ax.add_patch(plt.Circle((cx,cy),r,color=f,ec=e,lw=1.2,zorder=2))
    for r,lbl,e in zip(radii,lbls,edges):
        ax.text(cx,cy+r*0.55,lbl,ha='center',va='center',
               fontsize=8,fontweight='bold',color=e,zorder=3)
    plt.tight_layout(pad=0.1)
    plt.savefig(str(fp),dpi=300,bbox_inches='tight',facecolor='white')
    plt.close()

def _draw_boxgrid(labels, fp, w=3.5, h=2.2):
    import matplotlib; matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    import matplotlib.patches as mpt
    fig, ax = plt.subplots(figsize=(w,h), dpi=300)
    ax.set_xlim(0,10); ax.set_ylim(0,10); ax.axis('off')
    fig.patch.set_facecolor('white')
    lbls = (labels or ["Box A","Box B","Box C","Box D"])[:4]
    positions = [(0.4,5.3),(5.2,5.3),(0.4,0.5),(5.2,0.5)]
    for (bx,by),lbl in zip(positions,lbls):
        ax.add_patch(mpt.FancyBboxPatch((bx,by),4.3,4.2,
            boxstyle="round,pad=0.1",facecolor='white',
            edgecolor='#AAAAAA',lw=1.2))
        ax.text(bx+2.15,by+2.1,lbl,ha='center',va='center',
               fontsize=9,fontweight='bold',color=INK)
    plt.tight_layout(pad=0.1)
    plt.savefig(str(fp),dpi=300,bbox_inches='tight',facecolor='white')
    plt.close()

def _draw_flowchart(labels, fp, w=5.5, h=3.5):
    import matplotlib; matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    import matplotlib.patches as mpt
    fig, ax = plt.subplots(figsize=(w,h), dpi=300)
    ax.set_xlim(0,10); ax.set_ylim(0,10); ax.axis('off')
    fig.patch.set_facecolor('white')
    lbls = (labels or ["Presentation","Assessment","Decision?","PathA","PathB","Management"])
    cx = 5.0
    def box(x,y,w,h,txt,fill,tc='white'):
        ax.add_patch(mpt.FancyBboxPatch((x-w/2,y),w,h,
            boxstyle="round,pad=0.1",facecolor=fill,edgecolor='#AAAAAA',lw=0.8))
        ax.text(x,y+h/2,txt[:28],ha='center',va='center',
               fontsize=7.5,fontweight='bold',color=tc)
    def arr(x0,y0,x1,y1):
        ax.annotate('',xy=(x1,y1),xytext=(x0,y0),
            arrowprops=dict(arrowstyle='->',color='#555555',lw=0.9))
    bw=3.5; bh=0.85; y1=8.8; y2=7.0; y3=5.2
    box(cx,y1,bw,bh,lbls[0] if len(lbls)>0 else "Presentation",NAVY)
    box(cx,y2,bw,bh,lbls[1] if len(lbls)>1 else "Assessment",TEAL)
    box(cx,y3,bw,bh,lbls[2] if len(lbls)>2 else "Decision?",RED)
    box(2.5,3.0,2.8,bh,lbls[3] if len(lbls)>3 else "Path A",NAVY)
    box(7.5,3.0,2.8,bh,lbls[4] if len(lbls)>4 else "Path B",TEAL)
    box(cx,1.2,bw,bh,lbls[5] if len(lbls)>5 else "Management",NAVY)
    arr(cx,y1,cx,y2+bh); arr(cx,y2,cx,y3+bh)
    arr(cx,y3,2.5,3.0+bh); arr(cx,y3,7.5,3.0+bh)
    arr(2.5,3.0,cx,1.2+bh); arr(7.5,3.0,cx,1.2+bh)
    ax.text(3.3,5.5,'YES',fontsize=7,color=RED,fontweight='bold')
    ax.text(6.7,5.5,'NO',fontsize=7,color=TEAL,fontweight='bold')
    plt.tight_layout(pad=0.1)
    plt.savefig(str(fp),dpi=300,bbox_inches='tight',facecolor='white')
    plt.close()

def _draw_ecg(label, fp, w=6.0, h=1.8):
    import matplotlib; matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    import numpy as np
    fig, ax = plt.subplots(figsize=(w,h), dpi=300)
    ax.set_facecolor('#FFF8F0')
    fig.patch.set_facecolor('#FFF8F0')
    for x in np.arange(0,10.1,0.2):
        lw=0.5 if x%1<0.01 else 0.2
        ax.axvline(x,color='#FFBBBB',lw=lw,zorder=1)
    for y in np.arange(-3,4,0.2):
        lw=0.5 if abs(y%1)<0.01 else 0.2
        ax.axhline(y,color='#FFBBBB',lw=lw,zorder=1)
    t=np.linspace(0,10,2000); sig=np.zeros_like(t)
    for tc in [1.2,3.7,6.2,8.7]:
        sk=t-tc
        sig+=np.exp(-(sk+0.5)**2/0.012)*0.7
        q=(sk>-0.07)&(sk<-0.02); sig[q]-=0.55
        r=(sk>-0.02)&(sk<0.05);  sig[r]+=2.2
        ss=(sk>0.05)&(sk<0.12);  sig[ss]-=1.0
        sig+=np.exp(-(sk-0.55)**2/0.022)*1.0
    ax.plot(t,sig,color='#CC2200',lw=1.3,zorder=2)
    ax.text(0.1,2.2,label or "Lead II",fontsize=7,fontweight='bold',color='#555555')
    ax.set_xlim(0,10); ax.set_ylim(-2.5,3.0)
    ax.axis('off')
    plt.tight_layout(pad=0.1)
    plt.savefig(str(fp),dpi=300,bbox_inches='tight',facecolor='#FFF8F0')
    plt.close()

print("✅ Figures — code drawn free | covers OpenAI")
