# ══════════════════════════════════════════════════════════════
# GROUP 1 — DIFFERENTIAL DIAGNOSIS
# Book 1: Claude Haiku writes + labels  ($2.79 total)
# Book 2: DeepSeek writes + labels      ($1.76 total)
# Interior: Template 29 exactly
# 8.5×11 | Navy/Teal/Red | Indented paragraphs | Numbered sections
# ══════════════════════════════════════════════════════════════

import os
from pathlib import Path
BASE_DIR = Path(__file__).parent.parent

# ── ANTHROPIC API (Claude Haiku) ───────────────────────────────
ANTHROPIC_API_KEY  = os.getenv("ANTHROPIC_API_KEY","")
CLAUDE_MODEL       = "claude-haiku-4-5-20251001"
CLAUDE_MAX_TOKENS  = 7000
CLAUDE_INPUT_COST  = 0.80  / 1_000_000
CLAUDE_OUTPUT_COST = 4.00  / 1_000_000
CLAUDE_SPEND       = 0.0   # tracked live
CLAUDE_LIMIT       = 8.00  # $8 for Book 1

# ── DEEPSEEK API (writing + labels) ───────────────────────────
DEEPSEEK_API_KEY   = os.getenv("DEEPSEEK_API_KEY","")
DEEPSEEK_BASE_URL  = "https://api.deepseek.com"
DEEPSEEK_MODEL     = "deepseek-chat"
DEEPSEEK_MAX_TOKENS = 2000   # FIXED: never more — no hanging
DS_INPUT_COST      = 0.28  / 1_000_000
DS_OUTPUT_COST     = 0.28  / 1_000_000
DS_LIMIT           = 5.00  # $5 for Book 2

# ── OPENAI API (covers only) ───────────────────────────────────
OPENAI_API_KEY     = os.getenv("OPENAI_API_KEY","")
OPENAI_MODEL       = "gpt-image-1"
OPENAI_QUALITY     = "medium"
OPENAI_SIZE        = "1024x1024"
OPENAI_COST        = 0.042
OPENAI_LIMIT       = 3.00  # $3 covers both books

# ── GROUP ──────────────────────────────────────────────────────
GROUP = {
    "name":      "Group 1 — Differential Diagnosis",
    "author":    "Vantage Medical Press",
    "publisher": "Vantage Medical Press",
    "part_label":"Part One    Foundations of Differential Diagnosis",
    "price_usd": 150.00,
    "price_eur": 135.00,
}

# ── 8 BOOKS ────────────────────────────────────────────────────
BOOKS = [
    {
        "no":1, "writer":"claude",
        "title_EN":"Advanced Practice Nursing: Differential Diagnosis and Clinical Decision-Making",
        "title_DE":"Advanced Practice Nursing: Differentialdiagnose und klinische Entscheidungsfindung",
        "subtitle_EN":"a systematic clinical reference for NPs and PAs",
        "subtitle_DE":"ein systematisches klinisches Nachschlagewerk für NPs und PAs",
        "trim_w":8.5,"trim_h":11,"pages":420,"chapters":18,
        "figures_code":38,"figures_ai":0,"front_figs":0,
        "audience":"NPs, PAs and advanced practice providers",
        "specialty":"differential diagnosis",
        "opener":"The patient in Room 4 has three diagnoses that all fit. Only one is correct. How you think through the next five minutes will determine which one you find.",
        "book_type":"clinical_reference",
    },
    {
        "no":2, "writer":"deepseek",
        "title_EN":"Clinical Reasoning and Differential Diagnosis for Advanced Practice Providers",
        "title_DE":"Klinisches Denken und Differentialdiagnose für Advanced Practice Provider",
        "subtitle_EN":"master the diagnostic process and make the right call every time",
        "subtitle_DE":"den diagnostischen Prozess meistern und jedes Mal die richtige Entscheidung treffen",
        "trim_w":8.5,"trim_h":11,"pages":400,"chapters":18,
        "figures_code":37,"figures_ai":0,"front_figs":0,
        "audience":"advanced practice providers",
        "specialty":"clinical reasoning and diagnostic frameworks",
        "opener":"Every misdiagnosis begins the same way — not with ignorance, but with a conclusion reached too early.",
        "book_type":"clinical_reference",
    },
    {
        "no":3, "writer":"deepseek",
        "title_EN":"Differential Diagnosis at the Bedside: A Compact Clinical Manual",
        "title_DE":"Differentialdiagnose am Krankenbett: Ein kompaktes klinisches Handbuch",
        "subtitle_EN":"","subtitle_DE":"",
        "trim_w":6,"trim_h":9,"pages":260,"chapters":14,
        "figures_code":25,"figures_ai":0,"front_figs":0,
        "audience":"clinicians at the bedside","specialty":"rapid differential diagnosis",
        "opener":"You have ninety seconds at the bedside. This manual is built for exactly that.",
        "book_type":"pocket_guide",
    },
    {
        "no":4, "writer":"deepseek",
        "title_EN":"Primary Care Differential Diagnosis: Assessment and Management Strategies",
        "title_DE":"Differentialdiagnose in der Primärversorgung: Befunderhebung und Behandlungsstrategien",
        "subtitle_EN":"","subtitle_DE":"",
        "trim_w":8.5,"trim_h":11,"pages":420,"chapters":18,
        "figures_code":38,"figures_ai":0,"front_figs":0,
        "audience":"primary care clinicians","specialty":"primary care differential diagnosis",
        "opener":"Primary care sees everything first. That is both the privilege and the clinical responsibility this book is designed to support.",
        "book_type":"clinical_reference",
    },
    {
        "no":5, "writer":"deepseek",
        "title_EN":"Family Medicine Differential Diagnosis Workbook",
        "title_DE":"Arbeitsbuch Differentialdiagnose in der Allgemeinmedizin",
        "subtitle_EN":"the practice-based workbook that builds real diagnostic confidence",
        "subtitle_DE":"das praxisbasierte Arbeitsbuch für echte diagnostische Sicherheit",
        "trim_w":8.5,"trim_h":11,"pages":400,"chapters":18,
        "figures_code":37,"figures_ai":0,"front_figs":0,
        "audience":"family medicine practitioners","specialty":"family medicine differential diagnosis",
        "opener":"Diagnostic confidence is not a talent. It is a skill. And like every skill, it is built through deliberate practice.",
        "book_type":"workbook",
    },
    {
        "no":6, "writer":"deepseek",
        "title_EN":"Psychiatry Differential Diagnosis in Primary Care",
        "title_DE":"Psychiatrische Differentialdiagnose in der Primärversorgung",
        "subtitle_EN":"recognise, diagnose and manage every psychiatric presentation",
        "subtitle_DE":"jede psychiatrische Präsentation erkennen, diagnostizieren und behandeln",
        "trim_w":8.5,"trim_h":11,"pages":400,"chapters":18,
        "figures_code":37,"figures_ai":0,"front_figs":0,
        "audience":"primary care clinicians managing psychiatric presentations",
        "specialty":"psychiatry differential diagnosis",
        "opener":"The patient sitting across from you has already seen their symptoms dismissed twice. Getting the diagnosis right — the first time — changes everything.",
        "book_type":"clinical_reference",
    },
    {
        "no":7, "writer":"deepseek",
        "title_EN":"Endocrinology Differential Diagnosis",
        "title_DE":"Differentialdiagnose in der Endokrinologie",
        "subtitle_EN":"the complete guide to every hormonal and metabolic presentation",
        "subtitle_DE":"der vollständige Leitfaden für jede hormonelle und metabolische Präsentation",
        "trim_w":8.5,"trim_h":11,"pages":420,"chapters":18,
        "figures_code":36,"figures_ai":0,"front_figs":0,
        "audience":"endocrinologists and clinicians managing metabolic conditions",
        "specialty":"endocrinology differential diagnosis",
        "opener":"Hormonal disorders are masters of disguise. The same fatigue that looks like depression can be hypothyroidism.",
        "book_type":"clinical_reference",
    },
    {
        "no":8, "writer":"deepseek",
        "title_EN":"Cardiology Differential Diagnosis in Primary Care",
        "title_DE":"Kardiologische Differentialdiagnose in der Primärversorgung",
        "subtitle_EN":"never miss a cardiac diagnosis in primary care again",
        "subtitle_DE":"keine kardiale Diagnose in der Primärversorgung mehr verpassen",
        "trim_w":8.5,"trim_h":11,"pages":420,"chapters":18,
        "figures_code":36,"figures_ai":0,"front_figs":0,
        "audience":"primary care clinicians managing cardiac presentations",
        "specialty":"cardiology differential diagnosis",
        "opener":"Chest pain walks into primary care every day. Most of it is not cardiac. Some of it is. Knowing the difference before the patient leaves your room is what this book is about.",
        "book_type":"clinical_reference",
    },
]

TEST_MODE       = True
TEST_BOOKS      = [0, 1]  # Book 1 (Claude) + Book 2 (DeepSeek)

OUTPUT_DIR = BASE_DIR/"output"; PDFS_DIR   = BASE_DIR/"pdfs"
COVERS_DIR = BASE_DIR/"covers"; LOGS_DIR   = BASE_DIR/"logs"
STATE_DIR  = BASE_DIR/"state";  FIGS_DIR   = BASE_DIR/"figs"
STATE_FILE = STATE_DIR/"state.json"
SPEND_FILE = STATE_DIR/"spend.json"

print("✅ Config — T29 interior | Book 1 Claude | Books 2-8 DeepSeek")
