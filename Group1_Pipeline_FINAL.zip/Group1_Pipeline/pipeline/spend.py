# Spend tracker — enforces exact costs, never stops pipeline
import json, time
from pathlib import Path
from config import (ANTHROPIC_API_KEY, CLAUDE_INPUT_COST, CLAUDE_OUTPUT_COST, CLAUDE_LIMIT,
                    DEEPSEEK_API_KEY, DS_INPUT_COST, DS_OUTPUT_COST, DS_LIMIT,
                    OPENAI_API_KEY, OPENAI_COST, OPENAI_LIMIT, SPEND_FILE)

def _load():
    if SPEND_FILE.exists(): return json.loads(SPEND_FILE.read_text())
    return {"claude":{"spent":0.0,"calls":0},"deepseek":{"spent":0.0,"calls":0},
            "openai":{"spent":0.0,"calls":0},"per_book":{},"total":0.0,"log":[]}

def _save(s): SPEND_FILE.parent.mkdir(parents=True,exist_ok=True); SPEND_FILE.write_text(json.dumps(s,indent=2))

def can_claude(est_out=7000):
    s=_load(); est=est_out*CLAUDE_OUTPUT_COST
    if s["claude"]["spent"]+est>=CLAUDE_LIMIT: print(f"⛔ Claude ${s['claude']['spent']:.4f}/${CLAUDE_LIMIT}"); return False
    return True

def can_deepseek(est_out=2000):
    s=_load(); est=est_out*DS_OUTPUT_COST
    if s["deepseek"]["spent"]+est>=DS_LIMIT: print(f"⛔ DeepSeek ${s['deepseek']['spent']:.4f}/${DS_LIMIT}"); return False
    return True

def can_openai():
    s=_load()
    if s["openai"]["spent"]+OPENAI_COST>=OPENAI_LIMIT: print(f"⛔ OpenAI ${s['openai']['spent']:.4f}/${OPENAI_LIMIT}"); return False
    return True

def log_claude(bid,label,tok_in,tok_out):
    cost=tok_in*CLAUDE_INPUT_COST+tok_out*CLAUDE_OUTPUT_COST; s=_load()
    s["claude"]["spent"]=round(s["claude"]["spent"]+cost,6); s["claude"]["calls"]+=1
    s["per_book"][bid]=round(s["per_book"].get(bid,0.0)+cost,6)
    s["total"]=round(s["total"]+cost,6)
    s["log"].append({"t":time.strftime("%H:%M:%S"),"svc":"claude","book":bid,"label":label,
        "in":tok_in,"out":tok_out,"cost":round(cost,6),"total":s["claude"]["spent"]})
    _save(s)
    print(f"💰 CLAUDE|{bid}|{label}|in:{tok_in} out:{tok_out}|${cost:.5f}|Claude:${s['claude']['spent']:.4f}/${CLAUDE_LIMIT}")

def log_deepseek(bid,label,tok_in,tok_out):
    cost=tok_in*DS_INPUT_COST+tok_out*DS_OUTPUT_COST; s=_load()
    s["deepseek"]["spent"]=round(s["deepseek"]["spent"]+cost,6); s["deepseek"]["calls"]+=1
    s["per_book"][bid]=round(s["per_book"].get(bid,0.0)+cost,6)
    s["total"]=round(s["total"]+cost,6)
    s["log"].append({"t":time.strftime("%H:%M:%S"),"svc":"deepseek","book":bid,"label":label,
        "in":tok_in,"out":tok_out,"cost":round(cost,6),"total":s["deepseek"]["spent"]})
    _save(s)
    print(f"💰 DS|{bid}|{label}|in:{tok_in} out:{tok_out}|${cost:.5f}|DS:${s['deepseek']['spent']:.4f}/${DS_LIMIT}")

def log_openai(bid,label):
    s=_load(); s["openai"]["spent"]=round(s["openai"]["spent"]+OPENAI_COST,6)
    s["openai"]["calls"]+=1; s["per_book"][bid]=round(s["per_book"].get(bid,0.0)+OPENAI_COST,6)
    s["total"]=round(s["total"]+OPENAI_COST,6)
    s["log"].append({"t":time.strftime("%H:%M:%S"),"svc":"openai","book":bid,"label":label,
        "cost":OPENAI_COST,"total":s["openai"]["spent"]})
    _save(s)
    print(f"💰 OAI|{bid}|{label}|${OPENAI_COST:.3f}|OAI:${s['openai']['spent']:.4f}/${OPENAI_LIMIT}")

def summary():
    s=_load()
    return {"claude":s["claude"]["spent"],"deepseek":s["deepseek"]["spent"],
            "openai":s["openai"]["spent"],"total":s["total"]}

print("✅ Spend tracker — Claude $8 | DeepSeek $5 | OpenAI $3")
