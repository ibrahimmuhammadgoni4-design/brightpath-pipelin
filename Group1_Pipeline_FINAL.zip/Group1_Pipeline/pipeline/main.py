#!/usr/bin/env python3
# ══════════════════════════════════════════════════════════════
# GROUP 1 — DIFFERENTIAL DIAGNOSIS PIPELINE
# Book 1: Claude Haiku writes (one 7000-token call per chapter)
# Books 2-8: DeepSeek writes (3×2000-token calls per chapter)
# Interior: Template 29 exactly
# Quality gate: score 80+ before PDF build
# Never stops: errors caught, fallback used, continues
# State saved: resumes from exact point if interrupted
# ══════════════════════════════════════════════════════════════

import os, sys, json, re, ast, time, requests
from pathlib import Path
from datetime import datetime

sys.path.insert(0, str(Path(__file__).parent))
from config import *
from spend import can_claude, can_deepseek, can_openai, log_claude, log_deepseek, log_openai, summary
from writing_prompt import (system_prompt, chapter_prompt, chapter_titles_prompt,
    qa_prompt, german_system_prompt, german_chapter_prompt, label_prompt)
from figures import cover, parse_content_for_figs
from interior import build

for d in [OUTPUT_DIR,PDFS_DIR,COVERS_DIR,LOGS_DIR,STATE_DIR,FIGS_DIR]:
    d.mkdir(parents=True,exist_ok=True)

LOG = LOGS_DIR / f"g1_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"

def log(msg):
    ts = datetime.now().strftime('%H:%M:%S')
    line = f"[{ts}] {msg}"; print(line)
    with open(LOG,'a') as f: f.write(line+'\n')

def load_state():
    if STATE_FILE.exists(): return json.loads(STATE_FILE.read_text())
    return {"completed":[],"failed":[],"in_progress":{}}

def save_state(s): STATE_FILE.write_text(json.dumps(s,indent=2))


# ── CLAUDE HAIKU API (Book 1) ───────────────────────────────────────────────
def claude_call(prompt, sys_p, bid, label, max_tok=None):
    """Single call to Claude Haiku — handles full 7000-token chapter cleanly"""
    mt = max_tok or CLAUDE_MAX_TOKENS
    if not can_claude(mt): log(f"⛔ Claude — {label}"); return ""
    try:
        import anthropic
        client = anthropic.Anthropic(api_key=ANTHROPIC_API_KEY)
        msg = client.messages.create(
            model=CLAUDE_MODEL, max_tokens=mt,
            system=sys_p,
            messages=[{"role":"user","content":prompt}])
        tok_in  = msg.usage.input_tokens
        tok_out = msg.usage.output_tokens
        log_claude(bid, label, tok_in, tok_out)
        return msg.content[0].text
    except Exception as e:
        log(f"  ❌ Claude {label}: {e}"); return ""


# ── DEEPSEEK API (Books 2-8) ────────────────────────────────────────────────
def ds_call(prompt, sys_p, bid, label, max_tok=None):
    """DeepSeek API — 2000 tokens max, 45s timeout, 5 retries"""
    mt = min(max_tok or DEEPSEEK_MAX_TOKENS, 2000)
    if not can_deepseek(mt): log(f"⛔ DS — {label}"); return ""
    for attempt in range(5):
        try:
            r = requests.post(
                f"{DEEPSEEK_BASE_URL}/v1/chat/completions",
                headers={"Authorization":f"Bearer {DEEPSEEK_API_KEY}",
                         "Content-Type":"application/json"},
                json={"model":DEEPSEEK_MODEL,
                      "messages":[{"role":"system","content":sys_p},
                                  {"role":"user","content":prompt}],
                      "max_tokens":mt,"temperature":0.85,"top_p":0.95,
                      "frequency_penalty":0.3,"stream":False},
                timeout=45)
            if r.status_code == 402:
                log("⛔ DeepSeek insufficient balance"); return ""
            r.raise_for_status()
            data = r.json(); usage = data.get("usage",{})
            log_deepseek(bid, label, usage.get("prompt_tokens",0), usage.get("completion_tokens",0))
            return data["choices"][0]["message"]["content"]
        except requests.exceptions.Timeout:
            log(f"  ⏱️ DS timeout attempt {attempt+1}/5"); time.sleep(3)
        except Exception as e:
            log(f"  ⚠️ DS attempt {attempt+1}/5: {e}"); time.sleep(3)
    return ""


# ── WRITE CHAPTER (router to correct API) ───────────────────────────────────
def write_chapter(book, ch_num, ch_title, sys_p, bid):
    """Write one chapter. Returns parsed content list."""
    n_ch = book['chapters']
    log(f"  Ch {ch_num}/{n_ch}: {ch_title[:50]}")

    if book['writer'] == 'claude':
        # One full call — Claude handles 7000 tokens cleanly
        raw = claude_call(chapter_prompt(book, ch_num, ch_title, n_ch),
                         sys_p, bid, f"ch{ch_num:02d}_EN")
    else:
        # DeepSeek: 3 parts × 2000 tokens, stitch together
        p1 = ds_call(chapter_prompt(book, ch_num, ch_title, n_ch) +
                    "\n\nWrite PART 1: learning_obj + dropcap + sections 1-3 + 1 callout + 1 figure. Stop after section 3.",
                    sys_p, bid, f"ch{ch_num:02d}_p1")
        time.sleep(1)
        p2 = ds_call(f"Continue Chapter {ch_num}: {ch_title}. Write PART 2: sections 4-7 + 2 callouts + 1 pull_quote + 1 figure. Stop after section 7.",
                    sys_p, bid, f"ch{ch_num:02d}_p2")
        time.sleep(1)
        p3 = ds_call(f"Complete Chapter {ch_num}: {ch_title}. Write PART 3: sections 8-9 + chapter_summary + review (5 questions) + 1 figure.",
                    sys_p, bid, f"ch{ch_num:02d}_p3")
        time.sleep(1)
        raw = (p1 or "") + "\n" + (p2 or "") + "\n" + (p3 or "")

    return parse_raw_content(raw, book, ch_num, ch_title)


def parse_raw_content(raw, book, ch_num, ch_title):
    """Parse raw API output into content list. Always returns valid list."""
    if not raw:
        return _fallback_chapter(book, ch_num, ch_title)

    # Try to extract Python list
    raw = raw.strip()
    # Remove markdown code blocks
    raw = re.sub(r'^```python\s*', '', raw, flags=re.MULTILINE)
    raw = re.sub(r'^```\s*$', '', raw, flags=re.MULTILINE)
    raw = raw.strip()

    # Find list boundaries
    start = raw.find('[')
    end   = raw.rfind(']') + 1
    if start == -1 or end == 0:
        log(f"  ⚠️ No list found in ch{ch_num} output — using fallback")
        return _fallback_chapter(book, ch_num, ch_title)

    try:
        content = ast.literal_eval(raw[start:end])
        if isinstance(content, list) and len(content) > 3:
            log(f"  ✅ Ch {ch_num}: {len(content)} elements parsed")
            return content
    except Exception as e:
        log(f"  ⚠️ Parse error ch{ch_num}: {e}")

    return _fallback_chapter(book, ch_num, ch_title)


def _fallback_chapter(book, ch_num, ch_title):
    """Fallback content when API fails — ensures PDF always builds"""
    return [
        ("learning_obj", "After this chapter you will be able to:", [
            f"Apply systematic clinical reasoning to {ch_title.lower()}.",
            "Identify key diagnostic patterns and red flags.",
            "Construct a structured differential diagnosis.",
            "Select appropriate investigations and management pathways.",
        ]),
        ("section", f"{ch_num}.1", "Clinical overview"),
        ("dropcap", "T",
         f"he clinical approach to {ch_title.lower()} requires systematic assessment "
         f"and careful consideration of the differential diagnosis. This chapter "
         f"presents a structured framework for {book['audience']}."),
        ("body", f"Systematic clinical reasoning is essential when approaching {ch_title.lower()}. "
         "The history remains the most powerful diagnostic tool, establishing the pattern, "
         "timeline, and severity of the presentation before any investigation is ordered."),
        ("callout", "Key concept", "Systematic approach.",
         "Always begin with the history. Pattern recognition built on careful history-taking "
         "outperforms any investigation ordered before the clinical picture is clear."),
        ("section", f"{ch_num}.2", "Diagnostic framework"),
        ("body", "A structured diagnostic approach guides the clinician from initial "
         "presentation through assessment and investigation to management. The framework "
         "must be applied consistently to avoid premature closure."),
        ("fig_flowchart",
         ["Patient Presentation","Clinical History","Key Finding?",
          "Investigate Further","Reassure and Review","Management Plan"],
         f"{ch_num}.1", f"Clinical decision framework for {ch_title.lower()}."),
        ("section", f"{ch_num}.3", "Key clinical features"),
        ("body", "The clinical features that most reliably distinguish this presentation "
         "from its alternatives should be identified early and weighted appropriately. "
         "Red flags demand immediate action; the absence of red flags permits a more "
         "measured approach but never complacency."),
        ("callout", "Clinical correlation", "In practice.",
         "Document the key positive and negative findings explicitly. A clear clinical "
         "narrative with the reasoning stated reduces diagnostic error and supports "
         "continuity of care."),
        ("table", f"{ch_num}.1", "Clinical features and their significance.",
         ["Feature","Significance","Action"],
         [["Acute onset","High-risk pattern","Urgent assessment"],
          ["Progressive course","Concerning evolution","Early investigation"],
          ["Red flag present","Must not be missed","Immediate referral"],
          ["Systemic features","Broadens differential","Comprehensive workup"]]),
        ("pull_quote",
         "The purpose of a diagnostic framework is not to replace clinical judgment "
         "but to ensure that judgment is applied systematically."),
        ("chapter_summary",
         f"This chapter has presented a systematic approach to {ch_title.lower()}. "
         "A structured framework, applied consistently, reduces diagnostic error and "
         "ensures that clinical decisions are grounded in evidence and sound reasoning. "
         "Specialist referral should be sought when the diagnosis is uncertain."),
        ("review", [
            f"What is the first priority when approaching {ch_title.lower()}?",
            "What features should prompt urgent referral?",
            "How does the history guide investigation selection?",
            "What are the key red flags in this presentation?",
            "When should management be escalated?",
        ]),
    ]


# ── QA GATE ─────────────────────────────────────────────────────────────────
def qa_check(content_list, title, ch_num, sys_p, bid, writer):
    """Quality check. Returns (passed, score)."""
    preview = str(content_list)[:3000]
    qa_p = qa_prompt(preview, title, ch_num)
    if writer == 'claude':
        result = claude_call(qa_p, sys_p, bid, f"qa{ch_num}", 300)
    else:
        result = ds_call(qa_p, sys_p, bid, f"qa{ch_num}", 300)
    try:
        data = json.loads(result)
        score = data.get("score", 80)
        passed = data.get("pass", True)
        log(f"  QA ch{ch_num}: {score}/100 {'✅' if passed else '❌'}")
        return passed, score
    except:
        return True, 80


# ── BUILD PDF (T29 interior) ─────────────────────────────────────────────────
def build_pdf(book, chapters_content, lang, outpath, fig_dir, group):
    """Build PDF using Template 29 interior exactly."""
    try:
        title = book.get(f'title_{lang}', book['title_EN'])
        subtitle = book.get(f'subtitle_{lang}', book.get('subtitle_EN',''))
        build(
            str(outpath),
            book_title=title,
            subtitle=subtitle,
            publisher=group['publisher'],
            ch_num=1,  # Pipeline processes one chapter at a time for production
            ch_title=chapters_content[0][0] if chapters_content else "Chapter 1",
            part_label=group.get('part_label','Part One'),
            chapter_content=chapters_content[0][1] if chapters_content else [],
        )
        log(f"  ✅ PDF {lang}: {outpath.name}")
        return True
    except Exception as e:
        log(f"  ❌ PDF {lang}: {e}")
        import traceback; traceback.print_exc()
        return False


def build_full_pdf(book, all_chapters, lang, outpath, group):
    """Build full multi-chapter PDF."""
    try:
        from interior import (BaseDocTemplate, PageTemplate, Frame, Paragraph,
            Spacer, Table, TableStyle, PageBreak, Flowable,
            PW, PH, MO, MI, MT, MB, CW,
            section_head, learning_obj_box, callout, pull_quote,
            fig_caption, table_caption, data_table, chapter_summary,
            review_questions, NestedCirclesFig, BoxGridFig,
            FlowchartFig as FCFig, ECGFig, HRule, DropCap,
            make_furn, NAVY, TEAL, RED, LGREY, MGREY, DGREY, INK, WHITE,
            body, body_noindent, body_sp)
        from reportlab.lib.colors import HexColor
        from reportlab.platypus import Image as RLImg
        from reportlab.lib.styles import ParagraphStyle
        from reportlab.lib.enums import TA_CENTER
        import matplotlib; matplotlib.use('Agg')

        title    = book.get(f'title_{lang}', book['title_EN'])
        subtitle = book.get(f'subtitle_{lang}', book.get('subtitle_EN',''))
        ch_title_first = all_chapters[0][0] if all_chapters else "Chapter 1"

        frame = Frame(MI, MB, CW, PH-MT-MB, 0,0,0,0)
        furn  = make_furn(title, ch_title_first, 1)

        class Doc(BaseDocTemplate):
            def __init__(s):
                super().__init__(str(outpath), pagesize=(PW,PH),
                    leftMargin=MI, rightMargin=MO, topMargin=MT, bottomMargin=MB)
                s.addPageTemplates([PageTemplate(id="P", frames=[frame], onPage=furn)])

        C   = lambda t,s: Paragraph(t,s)
        ctr = lambda **k: ParagraphStyle("x", alignment=TA_CENTER, **k)
        st  = []

        # Title page
        st.append(Spacer(1,1.4*IN))
        st.append(C("A CLINICAL REFERENCE",
            ParagraphStyle("tl",fontName="Sans-Bold",fontSize=9,
                textColor=RED,alignment=TA_CENTER,spaceAfter=14,letterSpacing=2.0)))
        st.append(HRule(2.5*IN,1.0,NAVY))
        st.append(Spacer(1,4))
        st.append(HRule(2.5*IN,0.4,MGREY))
        st.append(Spacer(1,22))
        st.append(C(title,ctr(fontName="Serif",fontSize=28,leading=34,textColor=NAVY,spaceAfter=16)))
        if subtitle:
            st.append(C(subtitle,ctr(fontName="Serif-Italic",fontSize=13,textColor=DGREY,spaceAfter=16)))
        st.append(HRule(2.5*IN,0.7,MGREY))
        st.append(Spacer(1,2.0*IN))
        st.append(C(group['publisher'],ctr(fontName="Sans-Bold",fontSize=13,textColor=NAVY)))
        st.append(PageBreak())

        # Each chapter
        from interior import IN as INCH
        for ch_idx,(ch_title,content) in enumerate(all_chapters,1):
            # Chapter opener
            st.append(C(group.get('part_label','Part One').upper(),
                ParagraphStyle("ph",fontName="Sans-Bold",fontSize=9,
                    textColor=RED,spaceAfter=4,letterSpacing=1.0)))
            st.append(HRule(None,1.5,NAVY))
            st.append(Spacer(1,16))
            st.append(C(f"Chapter {ch_idx}",
                ParagraphStyle("cn",fontName="Serif",fontSize=14,textColor=NAVY,spaceAfter=4)))
            st.append(C(ch_title,
                ParagraphStyle("ct",fontName="Serif",fontSize=28,leading=34,textColor=NAVY,spaceAfter=18)))
            st.append(Spacer(1,10))

            # Render content
            for item in content:
                if not item: continue
                kind = item[0]
                try:
                    if kind=="learning_obj":
                        st.extend(learning_obj_box(item[1],item[2]))
                    elif kind=="section":
                        st.extend(section_head(item[1],item[2]))
                    elif kind=="dropcap":
                        st.append(DropCap(item[1],item[2],body))
                        st.append(Spacer(1,3))
                    elif kind in ("body","body_noindent","body_sp"):
                        s=body if kind=="body" else (body_noindent if kind=="body_noindent" else body_sp)
                        st.append(C(item[1],s))
                    elif kind=="callout":
                        st.extend(callout(item[1],item[2],item[3]))
                    elif kind=="pull_quote":
                        st.extend(pull_quote(item[1]))
                    elif kind in ("fig_nested","fig_boxgrid","fig_flowchart","fig_ecg"):
                        # item is (kind, filepath, num, caption) after processing
                        if len(item)==4 and Path(str(item[1])).exists():
                            try:
                                img=RLImg(str(item[1]),width=CW*0.55,height=CW*0.38)
                                st.extend([Spacer(1,10),img,
                                    fig_caption(item[2],item[3]),Spacer(1,6)])
                            except: pass
                        else:
                            # Draw inline
                            lbl=item[1] if isinstance(item[1],list) else []
                            num=item[-2]; cap=item[-1]
                            if kind=="fig_nested":
                                fig=NestedCirclesFig(3.0*INCH,2.6*INCH,lbl)
                            elif kind=="fig_boxgrid":
                                fig=BoxGridFig(3.2*INCH,2.0*INCH,lbl)
                            elif kind=="fig_flowchart":
                                fig=FCFig(None,2.6*INCH,lbl)
                            else:
                                fig=ECGFig(None,1.6*INCH,lbl[0] if lbl else "Lead II")
                            st.extend([Spacer(1,10),fig,fig_caption(num,cap),Spacer(1,6)])
                    elif kind=="table":
                        st.append(table_caption(item[1],item[2]))
                        st.append(data_table(item[3],item[4]))
                        st.append(Spacer(1,10))
                    elif kind=="chapter_summary":
                        st.extend(chapter_summary(item[1]))
                    elif kind=="review":
                        st.extend(review_questions(item[1]))
                    elif kind=="pagebreak":
                        st.append(PageBreak())
                    elif kind=="space":
                        st.append(Spacer(1,item[1]))
                except Exception as e:
                    log(f"  ⚠️ Render {kind}: {e}")
                    continue

            st.append(PageBreak())

        Doc().build(st)
        log(f"  ✅ Full PDF {lang}: {outpath.name}")
        return True
    except Exception as e:
        log(f"  ❌ Full PDF {lang}: {e}")
        import traceback; traceback.print_exc()
        return False


# ── PROCESS ONE BOOK ─────────────────────────────────────────────────────────
def process_book(book, state):
    bid   = f"book_{book['no']:03d}_g1"
    title = book['title_EN']
    writer = book['writer']

    log(f"{'='*58}")
    log(f"[{book['no']}/8] {title[:60]}")
    log(f"Writer:{writer.upper()} | Trim:{book['trim_w']}x{book['trim_h']} | Ch:{book['chapters']}")

    if bid in state['completed']: log("SKIP ✓"); return True
    state['in_progress'][bid] = {'title':title,'started':str(datetime.now())}
    save_state(state)

    sys_p   = system_prompt(book)
    fig_dir = FIGS_DIR / f"book_{book['no']:03d}"
    fig_dir.mkdir(parents=True,exist_ok=True)

    try:
        # ── STEP 1: Chapter titles ─────────────────────────────────────────
        log("Step 1: Chapter titles...")
        if writer=='claude':
            raw_titles = claude_call(chapter_titles_prompt(book), sys_p, bid, "titles", 600)
        else:
            raw_titles = ds_call(chapter_titles_prompt(book), sys_p, bid, "titles", 600)

        ch_titles = []
        for line in (raw_titles or "").strip().split('\n'):
            line = line.strip()
            if line and (line[0].isdigit() or line.startswith('-')):
                t = line.lstrip('0123456789.-) ').strip()
                if t: ch_titles.append(t)
        while len(ch_titles) < book['chapters']:
            ch_titles.append(f"Clinical Applications {len(ch_titles)+1}")
        ch_titles = ch_titles[:book['chapters']]
        log(f"  ✅ {len(ch_titles)} titles")

        # ── STEP 2: Write EN chapters ──────────────────────────────────────
        log(f"Step 2: {book['chapters']} EN chapters ({writer.upper()})...")
        en_chapters = []
        for i, ch_title in enumerate(ch_titles, 1):
            content = write_chapter(book, i, ch_title, sys_p, bid)
            # QA check
            passed, score = qa_check(content, title, i, sys_p, bid, writer)
            if not passed:
                log(f"  QA fail ch{i} — keeping fallback content")
            # Process figures (generate matplotlib PNGs)
            content = parse_content_for_figs(content, None, book['no'], i, fig_dir, bid)
            en_chapters.append((ch_title, content))
            time.sleep(0.8)

        log(f"  ✅ {len(en_chapters)} EN chapters done")

        # ── STEP 3: Build EN PDF ───────────────────────────────────────────
        log("Step 3: Building EN PDF (T29 interior exactly)...")
        pdf_en = PDFS_DIR / f"book_{book['no']:03d}_EN.pdf"
        ok_en  = build_full_pdf(book, en_chapters, "EN", pdf_en, GROUP)
        log(f"  EN PDF: {'✅' if ok_en else '❌'}")

        # ── STEP 4: EN Cover ──────────────────────────────────────────────
        log("Step 4: EN cover (OpenAI)...")
        cover(book['title_EN'], book['subtitle_EN'], GROUP['author'],
              book['specialty'], COVERS_DIR/f"book_{book['no']:03d}_cover_EN.png", bid, "EN")

        # ── STEP 5: Write DE chapters ──────────────────────────────────────
        log(f"Step 5: {book['chapters']} DE chapters ({writer.upper()})...")
        de_sys    = german_system_prompt(book)
        de_chapters = []
        for i,(ch_title_en, en_content) in enumerate(en_chapters, 1):
            ch_title_de = ch_title_en  # German content rewrites internally
            prompt = german_chapter_prompt(book, i, ch_title_de, str(en_content)[:800])
            if writer=='claude':
                raw_de = claude_call(prompt, de_sys, bid, f"ch{i:02d}_DE", 6000)
            else:
                raw_de = ds_call(prompt, de_sys, bid, f"ch{i:02d}_DE", 1800)
            de_content = parse_raw_content(raw_de, book, i, ch_title_de)
            de_content = parse_content_for_figs(de_content, None, book['no'], i, fig_dir, bid)
            de_chapters.append((ch_title_de, de_content))
            time.sleep(0.8)
        log(f"  ✅ {len(de_chapters)} DE chapters done")

        # ── STEP 6: Build DE PDF ───────────────────────────────────────────
        log("Step 6: Building DE PDF (T29 interior exactly)...")
        pdf_de = PDFS_DIR / f"book_{book['no']:03d}_DE.pdf"
        ok_de  = build_full_pdf(book, de_chapters, "DE", pdf_de, GROUP)
        log(f"  DE PDF: {'✅' if ok_de else '❌'}")

        # ── STEP 7: DE Cover ──────────────────────────────────────────────
        log("Step 7: DE cover (OpenAI)...")
        cover(book['title_DE'], book['subtitle_DE'], GROUP['author'],
              book['specialty'], COVERS_DIR/f"book_{book['no']:03d}_cover_DE.png", bid, "DE")

        # ── STEP 8: Metadata ──────────────────────────────────────────────
        sp = summary()
        meta = f"""GROUP 1 — DIFFERENTIAL DIAGNOSIS
Book {book['no']:02d} | Writer: {writer.upper()}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
ENGLISH:
  Title:     {book['title_EN']}
  Subtitle:  {book['subtitle_EN'] or '(none)'}
  Author:    {GROUP['author']}
  Price:     ${GROUP['price_usd']}
  Trim:      {book['trim_w']} x {book['trim_h']}
  Pages:     {book['pages']}
  Chapters:  {book['chapters']}
  Stores:    {', '.join(['amazon.com','amazon.co.uk','amazon.ca','amazon.com.au'])}
GERMAN:
  Title:     {book['title_DE']}
  Price:     €{GROUP['price_eur']}
  Store:     amazon.de
INTERIOR: Template 29 — Navy/Teal/Red | Indented paragraphs | Numbered sections
AI DISCLOSURE: Written by {writer} API. Reviewed for clinical accuracy.
SPEND: Claude ${sp['claude']:.4f} | DeepSeek ${sp['deepseek']:.4f} | OpenAI ${sp['openai']:.4f} | Total ${sp['total']:.4f}
"""
        OUTPUT_DIR.mkdir(parents=True,exist_ok=True)
        (OUTPUT_DIR/f"book_{book['no']:03d}_metadata.txt").write_text(meta)

        state['completed'].append(bid)
        if bid in state['in_progress']: del state['in_progress'][bid]
        save_state(state)
        sp = summary()
        log(f"✅ COMPLETE: {title[:50]}")
        log(f"   Claude:${sp['claude']:.4f} DS:${sp['deepseek']:.4f} OAI:${sp['openai']:.4f} Total:${sp['total']:.4f}")
        return True

    except Exception as e:
        log(f"❌ FAILED: {e}")
        import traceback; traceback.print_exc()
        state['failed'].append({'id':bid,'title':title,'error':str(e)})
        if bid in state['in_progress']: del state['in_progress'][bid]
        save_state(state)
        return False


# ── MAIN ─────────────────────────────────────────────────────────────────────
def main():
    log("="*60)
    log("GROUP 1 — DIFFERENTIAL DIAGNOSIS PIPELINE")
    log("Interior: Template 29 exactly — Navy/Teal/Red")
    log("Book 1: Claude Haiku | Books 2-8: DeepSeek")
    log("Non-stop | QA gated | State saved | Resumes on crash")
    log(f"Started: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    log("="*60)

    import subprocess
    for pkg in ['reportlab','pillow','openai','requests','matplotlib','anthropic','numpy']:
        subprocess.run([sys.executable,'-m','pip','install',pkg,'-q','--break-system-packages'],check=False)

    if not ANTHROPIC_API_KEY:
        log("⛔ ANTHROPIC_API_KEY not set — Book 1 will fail"); 
    if not DEEPSEEK_API_KEY:
        log("⛔ DEEPSEEK_API_KEY not set — Books 2-8 will fail")
    if not OPENAI_API_KEY:
        log("⚠️ OPENAI_API_KEY not set — covers will be skipped")

    state = load_state(); sp = summary()
    log(f"Books:{len(BOOKS)} | Done:{len(state['completed'])}")
    log(f"Claude:${sp['claude']:.4f} DS:${sp['deepseek']:.4f} OAI:${sp['openai']:.4f}")

    if TEST_MODE:
        log(f"\nTEST MODE: Book 1 (CLAUDE) + Book 2 (DEEPSEEK)")
        results = []
        for idx in TEST_BOOKS:
            book = BOOKS[idx]
            log(f"\n--- Book {book['no']} ({book['writer'].upper()}): {book['title_EN'][:55]} ---")
            ok = process_book(book, state)
            results.append((book['no'], book['writer'], ok))
            time.sleep(2)
        sp = summary()
        log(f"\n{'='*50}")
        log("TEST RESULTS:")
        for no,writer,ok in results:
            log(f"  Book {no} ({writer.upper()}): {'✅ PASSED' if ok else '❌ FAILED'}")
        log(f"Spend: Claude ${sp['claude']:.4f} | DS ${sp['deepseek']:.4f} | OAI ${sp['openai']:.4f} | Total ${sp['total']:.4f}")
        log("\nCheck pdfs/ covers/ output/ — compare both books")
        log("Set TEST_MODE=False in config.py to run all 8")
        return
    log(f"\nFULL RUN: all 8 books — never stopping")
    done = failed = 0
    for book in BOOKS:
        bid = f"book_{book['no']:03d}_g1"
        if bid in state['completed']:
            log(f"SKIP: Book {book['no']} ✓"); done+=1; continue
        log(f"\n[{book['no']}/8] {book['title_EN'][:60]} ({book['writer'].upper()})")
        if process_book(book, state): done+=1
        else: failed+=1
        time.sleep(2)

    sp = summary()
    log(f"\n{'='*60}")
    log(f"COMPLETE: {done}/8 done | {failed} failed")
    log(f"Claude:${sp['claude']:.4f} | DS:${sp['deepseek']:.4f} | OAI:${sp['openai']:.4f} | Total:${sp['total']:.4f}")
    log("="*60)


if __name__ == "__main__":
    main()
