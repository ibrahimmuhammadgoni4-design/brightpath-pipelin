#!/usr/bin/env python3
"""
Interior matching Template 29 Textbook Academic exactly.
8.5x11 | TeXGyreTermes (serif) + TeXGyreHeros (sans) via Lora + Liberation
Teal/Navy accents | Indented paragraphs | Numbered sections | Two callout types
"""
from reportlab.lib.units import inch as IN
from reportlab.lib.colors import HexColor
from reportlab.lib.enums import TA_JUSTIFY, TA_LEFT, TA_CENTER, TA_RIGHT
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfbase.pdfmetrics import registerFont, registerFontFamily
from reportlab.platypus import (BaseDocTemplate, PageTemplate, Frame,
    Paragraph, Spacer, Table, TableStyle, PageBreak, Flowable)
from reportlab.lib.styles import ParagraphStyle
import math

# ── FONTS ──────────────────────────────────────────────────────
LORA = "/usr/share/fonts/truetype/google-fonts/"
for n,f in [("Serif","Lora-Variable"),("Serif-Bold","Lora-Variable"),
            ("Serif-Italic","Lora-Italic-Variable"),("Serif-BoldItalic","Lora-Italic-Variable")]:
    try: pdfmetrics.registerFont(TTFont(n, LORA+f+".ttf"))
    except: pass
try: registerFontFamily("Serif",normal="Serif",bold="Serif-Bold",
        italic="Serif-Italic",boldItalic="Serif-BoldItalic")
except: pass

L = "/usr/share/fonts/truetype/liberation/"
for n,f in [("Sans","LiberationSans-Regular"),("Sans-Bold","LiberationSans-Bold"),
            ("Sans-Italic","LiberationSans-Italic")]:
    try: pdfmetrics.registerFont(TTFont(n, L+f+".ttf"))
    except: pass
try: registerFontFamily("Sans",normal="Sans",bold="Sans-Bold",italic="Sans-Italic")
except: pass

# ── COLOURS ────────────────────────────────────────────────────
NAVY  = HexColor("#1E2E4A")   # dark navy — banners, chapter number
TEAL  = HexColor("#1B6B7B")   # teal — section headings, callout labels, running header
RED   = HexColor("#8C1F28")   # dark red — title page label, callout border
LGREY = HexColor("#F0F0F0")   # light grey — callout backgrounds, review box
MGREY = HexColor("#BBBBBB")   # medium grey — rules, table rules
DGREY = HexColor("#3A3A3A")   # dark grey — subtitle
INK   = HexColor("#111111")   # body text
WHITE = HexColor("#FFFFFF")

# ── PAGE ───────────────────────────────────────────────────────
PW, PH = 8.5*IN, 11*IN
MO, MI, MT, MB = 1.1*IN, 1.1*IN, 1.0*IN, 0.9*IN
CW = PW - MO - MI   # 6.3 inches = 453.6 pts

# ── STYLES ─────────────────────────────────────────────────────
body = ParagraphStyle("body", fontName="Serif", fontSize=10.5, leading=15.0,
    alignment=TA_JUSTIFY, textColor=INK, spaceAfter=0, firstLineIndent=18)
body_noindent = ParagraphStyle("bodyni", fontName="Serif", fontSize=10.5,
    leading=15.0, alignment=TA_JUSTIFY, textColor=INK, spaceAfter=0,
    firstLineIndent=0)
body_sp = ParagraphStyle("bodysp", fontName="Serif", fontSize=10.5, leading=15.0,
    alignment=TA_JUSTIFY, textColor=INK, spaceAfter=0, firstLineIndent=18,
    spaceBefore=8)

# ── HORIZONTAL RULE FLOWABLE ───────────────────────────────────
class HRule(Flowable):
    def __init__(s, w=None, t=0.7, c=MGREY, sa=0):
        super().__init__(); s.rw=w; s.t=t; s.c=c; s.sa=sa
    def wrap(s, aw, ah):
        s.w = s.rw if s.rw else aw
        return (s.w, s.t + s.sa)
    def draw(s):
        s.canv.setStrokeColor(s.c); s.canv.setLineWidth(s.t)
        s.canv.line(0, 0, s.w, 0)

# ── DROP CAP ───────────────────────────────────────────────────
class DropCap(Flowable):
    """Large drop cap letter matching Template 29 style"""
    def __init__(s, letter, rest, style, cap_size=38, cap_lines=3):
        super().__init__()
        s.letter = letter; s.rest = rest; s.style = style
        s.cap_size = cap_size; s.cap_lines = cap_lines
    def wrap(s, aw, ah):
        s.aw = aw
        s.cap_w = s.cap_size * 0.72
        s.cap_h = s.cap_size * 1.1
        # Measure rest paragraph
        p = Paragraph(s.rest, s.style)
        s.pw, s.ph = p.wrap(aw - s.cap_w - 6, ah)
        s.total_h = max(s.cap_h, s.ph)
        return (aw, s.total_h)
    def draw(s):
        c = s.canv
        # Draw cap letter
        c.setFont("Serif-Bold", s.cap_size)
        c.setFillColor(INK)
        c.drawString(0, s.total_h - s.cap_size * 0.82, s.letter)
        # Draw rest of paragraph to the right
        p = Paragraph(s.rest, s.style)
        p.wrap(s.aw - s.cap_w - 6, s.total_h)
        p.drawOn(c, s.cap_w + 6, s.total_h - s.ph)

# ── TEMPLATE 29 ELEMENTS ───────────────────────────────────────

def section_head(num, title):
    """3.1  Why structure matters — teal bold sans, with number"""
    return [
        Spacer(1, 14),
        Paragraph(f"{num}\u00a0\u00a0{title}",
            ParagraphStyle("sh", fontName="Sans-Bold", fontSize=11.5,
                textColor=TEAL, spaceAfter=5, spaceBefore=0)),
    ]

def learning_obj_box(intro, bullets):
    """Dark navy header box + light grey bullet list — Template 29 style"""
    # Header row
    hdr = Table([[Paragraph(intro,
        ParagraphStyle("lh", fontName="Serif", fontSize=10.5, leading=14,
            textColor=WHITE, spaceAfter=4))]],
        colWidths=[CW])
    hdr.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,-1),NAVY),
        ("LEFTPADDING",(0,0),(-1,-1),14),("RIGHTPADDING",(0,0),(-1,-1),14),
        ("TOPPADDING",(0,0),(-1,-1),10),("BOTTOMPADDING",(0,0),(-1,-1),6)]))
    # Bullets
    rows = [[Paragraph(f"\u2022\u00a0\u00a0{b}",
        ParagraphStyle("lb", fontName="Serif", fontSize=10.5, leading=15,
            textColor=INK, spaceAfter=4, firstLineIndent=0))]
        for b in bullets]
    bdy = Table(rows, colWidths=[CW-28])
    bdy.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,-1),LGREY),
        ("LEFTPADDING",(0,0),(-1,-1),14),("RIGHTPADDING",(0,0),(-1,-1),14),
        ("TOPPADDING",(0,0),(-1,-1),5),("BOTTOMPADDING",(0,0),(-1,-1),5),
        ("VALIGN",(0,0),(-1,-1),"TOP")]))
    # Outer box
    outer = Table([[hdr],[bdy]], colWidths=[CW])
    outer.setStyle(TableStyle([
        ("LEFTPADDING",(0,0),(-1,-1),0),("RIGHTPADDING",(0,0),(-1,-1),0),
        ("TOPPADDING",(0,0),(-1,-1),0),("BOTTOMPADDING",(0,0),(-1,-1),0),
        ("BOX",(0,0),(-1,-1),0.8,MGREY)]))
    return [Spacer(1,10), outer, Spacer(1,16)]

def callout(label, bold_lead, text, style="key"):
    """
    Template 29 callout box:
    - Teal label (Key concept / Clinical correlation)
    - Burgundy left border
    - Light grey background
    - Bold lead phrase + normal text
    """
    label_p = Paragraph(label,
        ParagraphStyle("cl", fontName="Sans-Bold", fontSize=10,
            textColor=TEAL, spaceAfter=3))
    if bold_lead:
        body_text = f"<b>{bold_lead}</b> {text}"
    else:
        body_text = text
    txt_p = Paragraph(body_text,
        ParagraphStyle("ct", fontName="Serif", fontSize=10.5, leading=14.5,
            textColor=INK, firstLineIndent=0))
    content = Table([[label_p], [txt_p]], colWidths=[CW-28])
    content.setStyle(TableStyle([
        ("LEFTPADDING",(0,0),(-1,-1),12),("RIGHTPADDING",(0,0),(-1,-1),12),
        ("TOPPADDING",(0,0),(-1,-1),0),("BOTTOMPADDING",(0,0),(-1,-1),0),
        ("BACKGROUND",(0,0),(-1,-1),LGREY)]))
    box = Table([[content]], colWidths=[CW])
    box.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,-1),LGREY),
        ("LINEBEFORE",(0,0),(0,-1),3.5,RED),
        ("LEFTPADDING",(0,0),(-1,-1),0),("RIGHTPADDING",(0,0),(-1,-1),14),
        ("TOPPADDING",(0,0),(-1,-1),10),("BOTTOMPADDING",(0,0),(-1,-1),10)]))
    return [Spacer(1,8), box, Spacer(1,12)]

def pull_quote(text):
    """Large italic centred — Template 29 style, white space above/below"""
    return [
        Spacer(1,16),
        Paragraph(text,
            ParagraphStyle("pq", fontName="Serif-Italic", fontSize=13.5,
                leading=19, textColor=INK, alignment=TA_CENTER,
                leftIndent=30, rightIndent=30)),
        Spacer(1,16),
    ]

def fig_caption(num, title):
    """Figure 3.1  The nested layers. — sans small centred"""
    return Paragraph(
        f"<b>Figure {num}</b>\u00a0\u00a0{title}",
        ParagraphStyle("fc", fontName="Sans", fontSize=9.5, leading=13,
            textColor=DGREY, alignment=TA_CENTER, spaceBefore=5, spaceAfter=12))

def table_caption(num, title):
    """Table 3.1  The three layers — caption ABOVE table"""
    return Paragraph(
        f"<b>Table {num}</b>\u00a0\u00a0{title}",
        ParagraphStyle("tc", fontName="Sans", fontSize=9.5, leading=13,
            textColor=DGREY, alignment=TA_CENTER, spaceAfter=6))

def data_table(headers, rows):
    """Clean minimal table — rules top/bottom, bold header"""
    data = [[Paragraph(h, ParagraphStyle("th", fontName="Sans-Bold",
        fontSize=10, textColor=INK)) for h in headers]]
    for row in rows:
        data.append([Paragraph(str(c), ParagraphStyle("td", fontName="Serif",
            fontSize=10.5, leading=14, textColor=INK)) for c in row])
    ncols = len(headers)
    cws = [CW/ncols] * ncols
    t = Table(data, colWidths=cws)
    stl = [
        ("LINEABOVE",(0,0),(-1,0),0.8,INK),
        ("LINEBELOW",(0,0),(-1,0),0.5,MGREY),
        ("LINEBELOW",(0,-1),(-1,-1),0.8,INK),
        ("LEFTPADDING",(0,0),(-1,-1),6),("RIGHTPADDING",(0,0),(-1,-1),6),
        ("TOPPADDING",(0,0),(-1,-1),5),("BOTTOMPADDING",(0,0),(-1,-1),5),
        ("VALIGN",(0,0),(-1,-1),"TOP"),
        ("ALIGN",(0,0),(-1,0),"LEFT"),
    ]
    t.setStyle(TableStyle(stl))
    return t

def chapter_summary(text):
    """Dark navy full-width banner header + grey body"""
    hdr = Table([[Paragraph("Chapter summary",
        ParagraphStyle("csh", fontName="Sans-Bold", fontSize=10.5,
            textColor=WHITE))]],
        colWidths=[CW])
    hdr.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,-1),NAVY),
        ("LEFTPADDING",(0,0),(-1,-1),14),("RIGHTPADDING",(0,0),(-1,-1),14),
        ("TOPPADDING",(0,0),(-1,-1),8),("BOTTOMPADDING",(0,0),(-1,-1),8)]))
    bdy = Table([[Paragraph(text,
        ParagraphStyle("csb", fontName="Serif", fontSize=10.5, leading=15,
            textColor=INK, firstLineIndent=0))]],
        colWidths=[CW-28])
    bdy.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,-1),LGREY),
        ("LEFTPADDING",(0,0),(-1,-1),14),("RIGHTPADDING",(0,0),(-1,-1),14),
        ("TOPPADDING",(0,0),(-1,-1),10),("BOTTOMPADDING",(0,0),(-1,-1),10)]))
    outer = Table([[hdr],[bdy]], colWidths=[CW])
    outer.setStyle(TableStyle([
        ("LEFTPADDING",(0,0),(-1,-1),0),("RIGHTPADDING",(0,0),(-1,-1),0),
        ("TOPPADDING",(0,0),(-1,-1),0),("BOTTOMPADDING",(0,0),(-1,-1),0)]))
    return [Spacer(1,14), outer, Spacer(1,10)]

def review_questions(questions):
    """Dark navy bar top + numbered list in light grey box"""
    bar = Table([[Paragraph("",
        ParagraphStyle("rb", fontName="Sans", fontSize=4, textColor=WHITE))]],
        colWidths=[CW])
    bar.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,-1),NAVY),
        ("TOPPADDING",(0,0),(-1,-1),8),("BOTTOMPADDING",(0,0),(-1,-1),8),
        ("LEFTPADDING",(0,0),(-1,-1),0),("RIGHTPADDING",(0,0),(-1,-1),0)]))
    rows = [[Paragraph(f"{i+1}.\u00a0\u00a0{q}",
        ParagraphStyle("rq", fontName="Serif", fontSize=10.5, leading=15,
            textColor=INK, firstLineIndent=0, spaceAfter=6))]
        for i,q in enumerate(questions)]
    bdy = Table(rows, colWidths=[CW-28])
    bdy.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,-1),LGREY),
        ("LEFTPADDING",(0,0),(-1,-1),14),("RIGHTPADDING",(0,0),(-1,-1),14),
        ("TOPPADDING",(0,0),(-1,-1),10),("BOTTOMPADDING",(0,0),(-1,-1),8),
        ("VALIGN",(0,0),(-1,-1),"TOP")]))
    outer = Table([[bar],[bdy]], colWidths=[CW])
    outer.setStyle(TableStyle([
        ("LEFTPADDING",(0,0),(-1,-1),0),("RIGHTPADDING",(0,0),(-1,-1),0),
        ("TOPPADDING",(0,0),(-1,-1),0),("BOTTOMPADDING",(0,0),(-1,-1),0),
        ("BOX",(0,0),(-1,-1),0.8,MGREY)]))
    return [Spacer(1,14), outer]

# ── CODE FIGURES ───────────────────────────────────────────────
class NestedCirclesFig(Flowable):
    """Nested circles diagram like Figure 3.1 in Template 29"""
    def __init__(s, w=3.2*IN, h=3.0*IN, labels=None):
        super().__init__(); s.fw=w; s.fh=h
        s.labels = labels or ["Purpose","Arrangement","Material"]
    def wrap(s, aw, ah): s.fw=min(s.fw,aw); return (s.fw, s.fh)
    def draw(s):
        c=s.canv; cx=s.fw/2; cy=s.fh/2
        radii=[s.fh*0.44, s.fh*0.30, s.fh*0.16]
        colors=[HexColor("#D8E8F0"), HexColor("#B8D0E8"), HexColor("#8CAECC")]
        borders=[HexColor("#7AAAC8"), RED, NAVY]
        for r,col,brd,lbl in zip(radii,colors,borders,s.labels):
            c.setFillColor(col); c.setStrokeColor(brd); c.setLineWidth(1.2)
            c.circle(cx,cy,r,fill=1,stroke=1)
        # Labels
        c.setFont("Sans-Bold",9)
        for r,lbl,col in zip(radii,s.labels,borders):
            c.setFillColor(col)
            c.drawCentredString(cx,cy+r*0.6-4,lbl)

class BoxGridFig(Flowable):
    """2x2 box grid like Figure 3.2 in Template 29"""
    def __init__(s, w=3.0*IN, h=2.2*IN, labels=None):
        super().__init__(); s.fw=w; s.fh=h
        s.labels = labels or ["Workaround","Runaway metric","Mystery part","Silent drift"]
    def wrap(s, aw, ah): s.fw=min(s.fw,aw); return (s.fw, s.fh)
    def draw(s):
        c=s.canv; bw=s.fw/2-6; bh=s.fh/2-6
        positions=[(3,s.fh/2+3),(s.fw/2+3,s.fh/2+3),(3,3),(s.fw/2+3,3)]
        for (bx,by),lbl in zip(positions,s.labels):
            c.setFillColor(WHITE); c.setStrokeColor(MGREY); c.setLineWidth(0.8)
            c.rect(bx,by,bw,bh,fill=1,stroke=1)
            c.setFillColor(INK); c.setFont("Sans-Bold",9.5)
            c.drawCentredString(bx+bw/2,by+bh/2-4,lbl)

class FlowchartFig(Flowable):
    """Diagnostic flowchart"""
    def __init__(s, w=None, h=2.8*IN, labels=None):
        super().__init__(); s.fw=w; s.fh=h
        s.labels = labels or ["Patient Presentation","Clinical Assessment",
            "Red Flag Present?","Urgent Pathway","Standard Pathway","Management"]
    def wrap(s, aw, ah):
        if not s.fw: s.fw=aw
        s.fw=min(s.fw,aw); return (s.fw, s.fh)
    def draw(s):
        c=s.canv; bw=2.0*IN; bh=0.42*IN; cx=s.fw/2
        y1=s.fh-bh-0.08*IN; y2=y1-0.62*IN; y3=y2-0.62*IN
        lx=s.fw*0.22; rx=s.fw*0.78; bw2=1.55*IN
        def box(x,y,w,h,txt,fill,tc=WHITE):
            c.setFillColor(fill); c.setStrokeColor(HexColor("#AAAAAA")); c.setLineWidth(0.7)
            c.roundRect(x-w/2,y,w,h,3,fill=1,stroke=1)
            c.setFillColor(tc); c.setFont("Sans-Bold",8)
            c.drawCentredString(x,y+h/2-3,txt[:32])
        def arr(x0,y0,x1,y1):
            c.setStrokeColor(DGREY); c.setLineWidth(0.8)
            c.line(x0,y0,x1,y1)
            a=math.atan2(y1-y0,x1-x0)
            c.setFillColor(DGREY)
            p=c.beginPath(); p.moveTo(x1,y1)
            p.lineTo(x1-6*math.cos(a-.4),y1-6*math.sin(a-.4))
            p.lineTo(x1-6*math.cos(a+.4),y1-6*math.sin(a+.4)); p.close()
            c.drawPath(p,fill=1,stroke=0)
        lbl=s.labels
        box(cx,y1,bw,bh,lbl[0] if len(lbl)>0 else "Presentation",NAVY)
        box(cx,y2,bw,bh,lbl[1] if len(lbl)>1 else "Assessment",TEAL)
        box(cx,y3,bw,bh,lbl[2] if len(lbl)>2 else "Decision?",RED)
        box(lx,y3-0.7*IN,bw2,bh,lbl[3] if len(lbl)>3 else "Pathway A",NAVY)
        box(rx,y3-0.7*IN,bw2,bh,lbl[4] if len(lbl)>4 else "Pathway B",TEAL)
        box(cx,y3-1.4*IN,bw,bh,lbl[5] if len(lbl)>5 else "Management",NAVY)
        arr(cx,y1,cx,y2+bh); arr(cx,y2,cx,y3+bh)
        arr(cx,y3,lx,y3-0.7*IN+bh); arr(cx,y3,rx,y3-0.7*IN+bh)
        arr(lx,y3-0.7*IN,cx,y3-1.4*IN+bh); arr(rx,y3-0.7*IN,cx,y3-1.4*IN+bh)
        c.setFont("Sans",7.5); c.setFillColor(RED)
        c.drawCentredString(cx*0.56,y3+0.05*IN,"YES")
        c.drawCentredString(cx*1.44,y3+0.05*IN,"NO")

class ECGFig(Flowable):
    def __init__(s, w=None, h=1.7*IN, label="Lead II — Normal Sinus Rhythm"):
        super().__init__(); s.fw=w; s.fh=h; s.label=label
    def wrap(s, aw, ah):
        if not s.fw: s.fw=aw
        s.fw=min(s.fw,aw); return (s.fw, s.fh)
    def draw(s):
        import numpy as np
        c=s.canv
        c.setFillColor(HexColor("#FFF8F0")); c.rect(0,0,s.fw,s.fh,fill=1,stroke=0)
        for x in range(0,int(s.fw)+1,int(s.fw/20)):
            lw=0.5 if (x//(int(s.fw/20)))%5==0 else 0.2
            col="#FFBBBB" if (x//(int(s.fw/20)))%5==0 else "#FFDDDD"
            c.setStrokeColor(HexColor(col)); c.setLineWidth(lw)
            c.line(x,0,x,s.fh)
        for y in range(0,int(s.fh)+1,int(s.fh/8)):
            c.setStrokeColor(HexColor("#FFDDDD")); c.setLineWidth(0.2)
            c.line(0,y,s.fw,y)
        t=np.linspace(0,10,2000); sig=np.zeros_like(t)+s.fh*0.52
        scx=s.fw/10; scy=s.fh*0.18
        for tc in [1.2,3.7,6.2,8.7]:
            sk=t-tc
            sig+=np.exp(-(sk+0.5)**2/0.012)*scy*0.7
            q=(sk>-0.07)&(sk<-0.02); sig[q]-=scy*0.55
            r=(sk>-0.02)&(sk<0.05); sig[r]+=scy*2.2
            ss=(sk>0.05)&(sk<0.12); sig[ss]-=scy*1.0
            sig+=np.exp(-(sk-0.55)**2/0.022)*scy*1.0
        pts=[(t[i]*scx,sig[i]) for i in range(len(t))]
        c.setStrokeColor(HexColor("#CC2200")); c.setLineWidth(1.3)
        p=c.beginPath(); p.moveTo(*pts[0])
        for pt in pts[1:]: p.lineTo(*pt)
        c.drawPath(p,fill=0,stroke=1)
        c.setFont("Sans-Bold",8); c.setFillColor(DGREY)
        c.drawString(6,s.fh-14,s.label)

# ── RUNNING HEADERS ────────────────────────────────────────────
def make_furn(book_title, ch_title, ch_num):
    def furn(c, d):
        pg = d.page
        if pg <= 1: return
        c.saveState()
        # Left: italic serif chapter title
        c.setFont("Serif-Italic", 9); c.setFillColor(DGREY)
        c.drawString(MI, PH-MT+16, ch_title)
        # Right: bold sans "Chapter N"
        c.setFont("Sans-Bold", 9); c.setFillColor(INK)
        c.drawRightString(PW-MO, PH-MT+16, f"Chapter {ch_num}")
        # Rule below both
        c.setStrokeColor(MGREY); c.setLineWidth(0.5)
        c.line(MI, PH-MT+10, PW-MO, PH-MT+10)
        # Page number centred bottom
        c.setFont("Serif", 9.5); c.setFillColor(INK)
        c.drawCentredString(PW/2, MB-22, str(pg-1))
        c.restoreState()
    return furn

# ── BUILD ──────────────────────────────────────────────────────
def build(out, book_title, subtitle, publisher,
          ch_num, ch_title, part_label,
          chapter_content):
    """
    Build complete sample PDF matching Template 29.
    chapter_content: list of ('type', *args) tuples
    """
    frame = Frame(MI, MB, CW, PH-MT-MB, 0,0,0,0)
    furn = make_furn(book_title, ch_title, ch_num)
    class Doc(BaseDocTemplate):
        def __init__(s):
            super().__init__(str(out), pagesize=(PW,PH),
                leftMargin=MI, rightMargin=MO, topMargin=MT, bottomMargin=MB)
            s.addPageTemplates([PageTemplate(id="P", frames=[frame], onPage=furn)])
    C = lambda t,s: Paragraph(t,s)
    ctr = lambda **k: ParagraphStyle("x", alignment=TA_CENTER, **k)
    st = []

    # ── PAGE 1: TITLE PAGE ─────────────────────────────────────
    st.append(Spacer(1, 1.4*IN))
    st.append(C("A TEXTBOOK OF FOUNDATIONS",
        ParagraphStyle("tl", fontName="Sans-Bold", fontSize=9,
            textColor=RED, alignment=TA_CENTER, spaceAfter=14,
            letterSpacing=2.0)))
    st.append(HRule(2.5*IN, 1.0, NAVY))
    st.append(Spacer(1,4))
    st.append(HRule(2.5*IN, 0.4, MGREY))
    st.append(Spacer(1,22))
    st.append(C(book_title,
        ctr(fontName="Serif", fontSize=32, leading=38,
            textColor=NAVY, spaceAfter=16)))
    st.append(C(subtitle,
        ctr(fontName="Serif-Italic", fontSize=14,
            textColor=DGREY, spaceAfter=16)))
    st.append(HRule(2.5*IN, 0.7, MGREY))
    st.append(Spacer(1, 2.0*IN))
    st.append(C(publisher,
        ctr(fontName="Sans-Bold", fontSize=13, textColor=NAVY)))
    st.append(PageBreak())

    # ── PAGE 2: CHAPTER OPENER ─────────────────────────────────
    # Running header for chapter pages — part label
    st.append(C(f"{part_label.upper()}",
        ParagraphStyle("ph", fontName="Sans-Bold", fontSize=9,
            textColor=RED, spaceAfter=4, letterSpacing=1.0)))
    st.append(HRule(None, 1.5, NAVY))
    st.append(Spacer(1, 16))
    st.append(C(f"Chapter {ch_num}",
        ParagraphStyle("cn", fontName="Serif", fontSize=14,
            textColor=NAVY, spaceAfter=4)))
    st.append(C(ch_title,
        ParagraphStyle("ct", fontName="Serif", fontSize=30,
            leading=36, textColor=NAVY, spaceAfter=18)))
    st.append(Spacer(1, 10))

    # Parse and render chapter content
    i = 0
    while i < len(chapter_content):
        item = chapter_content[i]
        kind = item[0]

        if kind == "learning_obj":
            st.extend(learning_obj_box(item[1], item[2]))
        elif kind == "section":
            st.extend(section_head(item[1], item[2]))
        elif kind == "dropcap":
            st.append(DropCap(item[1], item[2], body))
            st.append(Spacer(1, 3))
        elif kind == "body":
            st.append(C(item[1], body))
        elif kind == "body_noindent":
            st.append(C(item[1], body_noindent))
        elif kind == "body_sp":
            st.append(C(item[1], body_sp))
        elif kind == "callout":
            st.extend(callout(item[1], item[2], item[3]))
        elif kind == "pull_quote":
            st.extend(pull_quote(item[1]))
        elif kind == "fig_nested":
            fig = NestedCirclesFig(3.2*IN, 2.8*IN, item[1])
            st.extend([Spacer(1,10), fig, fig_caption(item[2], item[3]), Spacer(1,6)])
        elif kind == "fig_boxgrid":
            fig = BoxGridFig(3.0*IN, 2.0*IN, item[1])
            st.extend([Spacer(1,10), fig, fig_caption(item[2], item[3]), Spacer(1,6)])
        elif kind == "fig_flowchart":
            fig = FlowchartFig(None, 2.6*IN, item[1])
            st.extend([Spacer(1,10), fig, fig_caption(item[2], item[3]), Spacer(1,6)])
        elif kind == "fig_ecg":
            fig = ECGFig(None, 1.6*IN, item[1])
            st.extend([Spacer(1,10), fig, fig_caption(item[2], item[3]), Spacer(1,6)])
        elif kind == "table":
            st.append(table_caption(item[1], item[2]))
            st.append(data_table(item[3], item[4]))
            st.append(Spacer(1,10))
        elif kind == "chapter_summary":
            st.extend(chapter_summary(item[1]))
        elif kind == "review":
            st.extend(review_questions(item[1]))
        elif kind == "pagebreak":
            st.append(PageBreak())
        elif kind == "space":
            st.append(Spacer(1, item[1]))

        i += 1

    Doc().build(st)
    print("✅ Template 29 interior built")


# ── SAMPLE CONTENT ─────────────────────────────────────────────
content = [
    ("learning_obj",
     "After this chapter you will be able to:",
     ["read any system on its three layers — purpose, arrangement, and material;",
      "recognise the four common ways a structure fails;",
      "apply the layer model to diagnose and redesign a system."]),

    ("section", "3.1", "Why structure matters"),
    ("dropcap", "W",
     "hen we look at any system that works well over a long period, we usually find the same "
     "quiet quality underneath it: a clear structure. Structure is not decoration. It is the set "
     "of decisions about what belongs where, how the parts connect, and which rules hold the "
     "whole together. Get those decisions right and the system bends without breaking; get them "
     "wrong and every later effort fights the foundation."),
    ("body",
     "This chapter introduces a simple way to think about structure that applies whether you are "
     "designing an organisation, a piece of software, a building, or a course of study. The "
     "vocabulary is deliberately plain, because the ideas matter more than the jargon, and "
     "because a model you can explain to someone else in a sentence is a model you actually "
     "understand."),
    ("body",
     "We will move from the general to the particular: first, why structure deserves attention "
     "at all; then a three-layer model that separates what a system is for, how it is arranged, "
     "and what it is made of; finally, worked ways of reading those layers in things you already "
     "know, so the idea becomes a tool rather than a definition."),
    ("callout", "Key concept",
     "Key Idea.",
     "A good structure makes the right thing easy and the wrong thing hard. If people constantly "
     "work around the design, the design — not the people — is the problem."),

    ("section", "3.2", "The three layers"),
    ("body",
     "Every system can be read on three levels, and most confusion comes from mixing them up. "
     "The first layer is <i>purpose</i>: what the system exists to do, stated plainly enough "
     "that you could tell whether it succeeded. The second is <i>arrangement</i>: how the parts "
     "are organised and connected to serve that purpose. The third is <i>material</i>: the "
     "actual components, people, or tools the arrangement is built from."),
    ("body",
     "The layers are ordered for a reason. Purpose constrains arrangement, and arrangement "
     "constrains material, not the other way around. When a system drifts, it is almost always "
     "because a lower layer has quietly started to drive a higher one — the tool dictating the "
     "method, the method forgetting the goal. Reading the layers in order is how you catch "
     "that drift early."),
    ("fig_nested",
     ["Purpose", "Arrangement", "Material"],
     "3.1", "The nested layers."),

    ("section", "3.3", "Reading the layers"),
    ("body",
     "Consider something ordinary, like a public library. Its <i>purpose</i> is to give a "
     "community free access to knowledge. Its <i>arrangement</i> is the catalogue, the "
     "shelving, the reading rooms, and the staff who connect people to what they need. "
     "Its <i>material</i> is the books, the building, and the funding. Notice how a change "
     "at one layer ripples: move to digital lending (material) and the arrangement must "
     "change — no shelves, but a platform — yet the purpose holds steady."),
    ("table", "3.1", "The three layers in a public library.",
     ["Layer", "In a library"],
     [["Purpose","Free community access to knowledge"],
      ["Arrangement","Catalogue, shelving, reading rooms, staff"],
      ["Material","Books, building, funding"]]),
    ("pull_quote",
     "Purpose constrains arrangement; arrangement constrains material. "
     "Drift begins when that order quietly reverses."),
    ("body",
     "The same reading works for a hospital laboratory, a software product, or a school. "
     "The skill is to name each layer out loud and check that the lower ones still serve "
     "the higher ones. When they do, the system feels coherent. When they do not, it feels "
     "like effort, and no amount of extra work at the material layer will fix a fault in "
     "the purpose."),
    ("callout", "Clinical correlation",
     "In practice.",
     "Before changing a system, write its purpose in one sentence. If you cannot, that is the "
     "first thing to fix — not the tools."),

    ("section", "3.4", "A short history of an old idea"),
    ("body",
     "The instinct to separate purpose from material is old. Architects have long distinguished "
     "the brief a building must satisfy from the stone and steel that satisfy it, and the best "
     "of them refuse to let the material dictate the brief. Engineers learned the same lesson "
     "through failure: bridges that were beautiful as objects but forgot what they were for."),
    ("body",
     "What is newer is the attempt to state the idea generally, so that a lesson learned in "
     "one field can be carried into another. That is the ambition of this book. None of the "
     "examples will be unfamiliar; what may be new is seeing them as instances of one pattern, "
     "and gaining from that a vocabulary you can reuse."),

    ("section", "3.5", "Four ways a structure fails"),
    ("body",
     "Most structural failures are quiet. They do not announce themselves with a collapse; "
     "they show up as friction, as the growing sense that the system is working against the "
     "people inside it. Four patterns appear again and again, and once named they are hard to "
     "miss."),
    ("fig_boxgrid",
     ["Workaround", "Runaway metric", "Mystery part", "Silent drift"],
     "3.2", "Four ways a structure fails."),
    ("body",
     "The first is the workaround that becomes permanent, a private fix that quietly replaces "
     "the official path. The second is the metric that has become the goal, where a number "
     "once used to track success now drives behaviour for its own sake. The third is the part "
     "no one understands any more, kept running because removing it feels too risky. The fourth "
     "is the slowest and most dangerous: the silent drift in which the purpose itself is "
     "forgotten while everyone stays busy."),
    ("callout", "Key concept",
     "Watch for.",
     "A system in trouble usually shows it first as friction, not failure. When the official "
     "path and the real path diverge, trust the real path to tell you where the design is "
     "wrong."),

    ("section", "3.6", "A worked example: the small clinic"),
    ("body",
     "Take a small clinic that has grown busy. Its <i>purpose</i> is to treat patients safely "
     "and well. Its <i>arrangement</i> is the appointment system, the rooms, the records, and "
     "the flow from reception to consultation to follow-up. Its <i>material</i> is the staff, "
     "the equipment, and the building. As volume rises, cracks appear: the booking software "
     "(material) starts to dictate how long a consultation may last (arrangement), and soon "
     "the clinic measures success by appointments completed rather than patients helped."),
    ("body",
     "Read through the three layers, the fault is obvious. A tool has begun to drive the "
     "method, and a convenient metric has begun to stand in for the purpose. The fix is not "
     "more software or longer hours; it is to restate the purpose, then redesign the "
     "arrangement to serve it, and only then choose the tools."),

    ("section", "3.9", "Three questions before you build"),
    ("body",
     "Whenever you are about to design or repair a system, three questions cut through most "
     "of the confusion. What is this for, stated so plainly that success would be obvious? "
     "How should the parts be arranged to serve that, and only that? And what is the least "
     "we can build it from and still do the job well? Asked in that order, the questions keep "
     "the layers in their proper relationship."),
    ("callout", "Key concept",
     "The three questions.",
     "What is it for? How should it be arranged to serve that? What is the least it can be "
     "built from? Always in that order — purpose, then arrangement, then material."),

    ("section", "3.11", "Putting it together"),
    ("body",
     "Structure, then, is less about diagrams and more about discipline: the habit of "
     "separating what a thing is for from how it is built, and of changing the lower layers "
     "in service of the higher ones. It is unglamorous work, and it is the work that lasts."),

    ("chapter_summary",
     "Structure is the set of decisions about what belongs where and how the parts connect. "
     "Read every system on three layers — purpose, arrangement, material — and keep the lower "
     "layers in service of the higher. Name the purpose first; fix it before anything else."),

    ("review", [
        "What are the three layers of a system, in order?",
        "Which layer should constrain the others?",
        "What is the sign that a system has begun to drift?",
        "What is the first thing to do before changing a system?",
    ]),
]

build(
    "/mnt/user-data/outputs/Interior_T29.pdf",
    book_title="Advanced Practice Nursing:\nDifferential Diagnosis and Clinical Decision-Making",
    subtitle="a systematic clinical reference",
    publisher="Vantage Medical Press",
    ch_num=1,
    ch_title="The Diagnostic Reasoning Framework",
    part_label="Part One    Foundations",
    chapter_content=content,
)
