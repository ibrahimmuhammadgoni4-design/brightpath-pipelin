# Writing prompts — Template 29 style content generation
# Content is returned as a list of ('type', *args) tuples
# that the interior.py build() function renders directly

SAFETY = """
MEDICAL SAFETY — MANDATORY:
- Never specific drug doses → "per current guidelines"
- Never invented statistics → "evidence demonstrates"  
- Never named trials → "landmark studies show"
- Never universal lab values → "confirm against local ranges"
- Always recommend clinical judgement and specialist referral
"""

FORBIDDEN = ["in conclusion","in summary","to summarize","furthermore",
"moreover","additionally","in the realm of","multifaceted","delve into",
"navigating","embark on","leverage","robust","seamlessly",
"it is worth noting","at the end of the day","moving forward",
"needless to say","in this chapter we will","let us explore"]

CONTENT_TYPES = """
Return content as a Python list of tuples. Each tuple is one of:

("learning_obj", "After this chapter you will be able to:", ["bullet 1","bullet 2","bullet 3"])
("section", "X.Y", "Section title")
("dropcap", "LETTER", "rest of first paragraph text")
("body", "paragraph text — indented, justified")
("callout", "Key concept", "Bold lead.", "rest of callout text")
("callout", "Clinical correlation", "Bold lead.", "rest of callout text")  
("pull_quote", "large italic quote text")
("fig_nested", ["Label1","Label2","Label3"], "X.Y", "Caption text.")
("fig_boxgrid", ["Box1","Box2","Box3","Box4"], "X.Y", "Caption text.")
("fig_flowchart", ["Step1","Step2","Decision?","PathA","PathB","End"], "X.Y", "Caption text.")
("fig_ecg", "ECG label description", "X.Y", "Caption text.")
("table", "X.Y", "Table caption.", ["Col1","Col2"], [["row1col1","row1col2"],["row2col1","row2col2"]])
("chapter_summary", "Summary paragraph text.")
("review", ["Question 1?","Question 2?","Question 3?","Question 4?","Question 5?"])

RULES:
- Return ONLY the Python list — no other text, no markdown, no preamble
- Every chapter MUST have: learning_obj, minimum 8 sections, 3+ callouts, 1+ pull_quote
- Every chapter MUST end with: chapter_summary then review (5 questions)
- Minimum 3 figures per chapter (flowchart, table, and one other)
- Body paragraphs must be substantial — minimum 4 sentences each
- Use ("dropcap") only for the VERY FIRST paragraph of the chapter
- Inline italic for key clinical terms: <i>term</i>
- Callout bold lead phrase ends with period: "Key Idea." or "In practice."
"""

def system_prompt(book):
    return f"""You are a world-class senior clinician and medical educator.
Writing a premium $150 clinical reference: {book['title_EN']}
Audience: {book['audience']}
Specialty: {book['specialty']}

VOICE — non-negotiable:
1. PROFESSIONAL: senior specialist authority every sentence
2. TEACHING: explain WHY — mechanism to presentation to management  
3. DEEP: never surface level — clinical nuance throughout
4. CAPTIVATING: first sentence creates urgency or clinical scenario

{SAFETY}

FORBIDDEN PHRASES: {', '.join(FORBIDDEN[:8])}

{CONTENT_TYPES}"""

def chapter_prompt(book, ch_num, ch_title, n_ch):
    words_target = max(2800, (book['pages']*240)//n_ch)
    return f"""Write Chapter {ch_num} of {n_ch}: {ch_title}

Book: {book['title_EN']}
Audience: {book['audience']}
Target: {words_target} words minimum

OPENER for Chapter {ch_num}:
{book['opener'] if ch_num==1 else f'Write a captivating clinical opener for: {ch_title}. Use a clinical scenario. Never a definition. Never "In this chapter..."'}

REQUIRED IN THIS CHAPTER:
- learning_obj: 3-4 bullets starting "After this chapter you will be able to:"
- dropcap: first paragraph only — letter + rest of paragraph
- Minimum 8 numbered sections (X.1, X.2... where X={ch_num})
- Minimum 3 callouts (mix of Key concept and Clinical correlation)
- Minimum 1 pull_quote (key teaching statement)
- Minimum 3 figures: 1 flowchart + 1 table + 1 other (nested/boxgrid/ecg)
- chapter_summary: 3-4 sentences
- review: exactly 5 clinical reasoning questions

Return ONLY the Python list. Start with [ and end with ]"""

def chapter_titles_prompt(book):
    return f"""Generate {book['chapters']} chapter titles for:
"{book['title_EN']}" — for {book['audience']}

Rules:
- Clinically specific and meaningful
- Progressive: foundations to advanced practice  
- Cover the full scope of {book['specialty']}
- Return NUMBERED LIST ONLY — no other text"""

def qa_prompt(content_str, title, ch_num):
    return f"""Quality check this medical chapter content.
Book: {title} | Chapter: {ch_num}

Check for:
- Medical safety issues (specific doses, invented stats, named trials)
- Forbidden phrases (furthermore, in conclusion, etc.)
- Missing required elements (callouts, figures, summary, review)
- Surface-level content not worthy of a $150 book
- Weak opener (starts with definition or "In this chapter")

Score 0-100. Pass=80+
Return JSON only: {{"pass":true,"score":85,"issues":[]}}"""

def german_system_prompt(book):
    return f"""Du bist ein erfahrener deutschsprachiger Facharzt und Autor.
Buch: {book['title_DE']}
Publikum: {book['audience']}

WICHTIG: Schreibe KOMPLETT NEU auf Deutsch — keine wörtliche Übersetzung.
Gleiche Struktur wie das englische Original.
Alle Tuple-Typen exakt beibehalten.
Deutsche klinische Fachterminologie.
Gleiche Sicherheitsregeln wie auf Englisch."""

def german_chapter_prompt(book, ch_num, ch_title_de, en_content_preview):
    return f"""Schreibe Kapitel {ch_num}: {ch_title_de} komplett NEU auf Deutsch.

Buch: {book['title_DE']}
Gleiche Struktur: learning_obj, dropcap, sections, callouts, figures, summary, review

Englischer Inhalt zur ORIENTIERUNG (nicht übersetzen):
{en_content_preview[:1200]}

Return NUR die Python-Liste. Start mit [ Ende mit ]"""

def label_prompt(fig_type, description, ch_num, fig_num):
    return f"""Generate precise clinical labels for this medical figure.

Figure type: {fig_type}
Description: {description}
Chapter: {ch_num}, Figure: {fig_num}

Return a Python LIST of strings — labels only, nothing else.
Example: ["Label One", "Label Two", "Label Three"]
Labels must be clinically accurate, 2-4 words each."""

print("✅ Writing prompts loaded — T29 content format")
